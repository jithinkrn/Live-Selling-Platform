#importing libraries
import matplotlib.pyplot as plt
from flask import Flask, render_template, request, send_file
import matplotlib.pyplot as plt
import io
import pandas as pd
from flask_cors import CORS
from tensorflow import keras
from flask import jsonify
import mysql.connector
import matplotlib.ticker as ticker
plt.switch_backend('agg')

#creating instance of the class
app=Flask(__name__, template_folder='templates')
CORS(app, support_credentials=True)

#local database connection
#user change to your Mysql account username
#password change to your Mysql account password
mydb = mysql.connector.connect(
  host="localhost",
  user="gdipsa54",         
  password="gdipsa54",     
  database="livestream"
)

# # azure server database connection
# mydb = mysql.connector.connect(
#   host="gdipsa54team3.mysql.database.azure.com",
#   user="gdipsa54team3",
#   password="6W$3F9&4dsPB&h%q",
#   database="livestream" 
# )

def popularityChart(userId):
    db_cursor = mydb.cursor()
    # db_cursor.execute('SELECT order_date_time, id FROM orders')
    db_cursor.execute('select avg(num_likes) from stream_log')
    averageStreamerLikes = db_cursor.fetchall()
    db_cursor.execute("""select avg(num_likes) from stream_log where seller_id = %s""", (userId,))
    averageUserLikes = db_cursor.fetchall()
    userLikesAvg = 0
    streamerLikesAvg = 0
    #checking if the fetched data is empty (no likes yet) to assign default 0
    if bool(averageUserLikes[0][0]):
        userLikesAvg = userLikesAvg = int(averageUserLikes[0][0])      
        print(streamerLikesAvg)
    #checking if the fetched data is empty (no records yet in db)to assign default 0
    if bool(averageStreamerLikes[0][0]):
        streamerLikesAvg = int(averageStreamerLikes[0][0])
        print(streamerLikesAvg)
      
    # Creating dataframe from the data
    df_reaction = pd.DataFrame ({
        'Hearts': ['Likes'],
        'You' : [userLikesAvg],  
        'Average Streamer' : [streamerLikesAvg] 
    })
    
    plt.clf()
    df_reaction.plot.bar(x='Hearts', y =['You','Average Streamer'])
    plt.legend(loc=2)
    plt.xticks([])
    plt.title("Reactions (You  vs Average Streamer)") 
    plt.ylabel("Average Reaction/Stream")
    plt.tight_layout()   
      
    # after saving figure into a bytes object, it can be exposed via flask
    chart = io.BytesIO()
    plt.savefig(chart, format='png')
    chart.seek(0)    
    return chart
    
#Time series - moviving average plotting
def movingAverage():
    
    db_cursor = mydb.cursor()
    # db_cursor.execute('SELECT order_date_time, id FROM orders')
  
    db_cursor.execute('SELECT order_date_time, id FROM livestream.orders WHERE order_date_time BETWEEN (CURRENT_DATE() - INTERVAL 2 MONTH) AND CURRENT_DATE()')
    columns = db_cursor.description 
    orders = [{columns[index][0]:column for index, column in enumerate(value)} 
            for value in db_cursor.fetchall()]    
    orders_df = pd.DataFrame(orders)
    orders_df['order_date_time'] = pd.to_datetime(orders_df['order_date_time']).dt.date
    orders_df = orders_df.sort_values(by='order_date_time')
    orders_count = orders_df.groupby('order_date_time').nunique()
    orders_count.columns.values[0] = "Number_of_Orders"
    Recent_Period = 30
    orders_count = orders_count[-Recent_Period:]   

    rolling_mean_10 = orders_count.Number_of_Orders.rolling(window=10).mean().shift(1)

    plt.clf()
    plt.plot(orders_count.index, orders_count.Number_of_Orders, label='Orders')
    plt.plot(orders_count.index, rolling_mean_10, label='Predicted Ordes (10 Day SMA)', color='orange')
    plt.legend(loc='upper left')
    # plt.plot(orders_count.index, orders_count['Number of Orders'])
    plt.title("Number of Orders in last Month")
    plt.ylabel("Number of Orders")  
    plt.xlabel("Date")
    plt.xticks(rotation=15)
    plt.tight_layout()
             
    # after saving figure into a bytes object, it can be exposed via flask
    chart = io.BytesIO()
    plt.savefig(chart, format='png')
    chart.seek(0)
    # im = Image.open(buf)
    # im.show()
    # buf1.close()
    return chart 

#Bar Chart - Orders in last month anoatated by pime period
def plotOrdersByTime():    
    #database connection
    db_cursor = mydb.cursor()
    db_cursor.execute('SELECT order_date_time, id FROM livestream.orders WHERE order_date_time BETWEEN (CURRENT_DATE() - INTERVAL 1 MONTH) AND CURRENT_DATE()')
    columns = db_cursor.description 
    orders = [{columns[index][0]:column for index, column in enumerate(value)} 
        for value in db_cursor.fetchall()]

    orders_df = pd.DataFrame(orders)
    orders_df['order_time'] = pd.to_datetime(orders_df['order_date_time'], format='%H:%M:%S').dt.time
    orders_df['order_time'] = pd.to_datetime(orders_df['order_date_time']).apply(lambda x: x.replace(microsecond=0))
    orders_df['order_date'] = pd.to_datetime(orders_df['order_date_time']).dt.date
    orders_df['day_of_week'] = pd.to_datetime(orders_df['order_date']).dt.day_name()
 
    hours = pd.to_datetime(orders_df['order_time'], format='%H:%M:%S').dt.hour
    orders_df['time_period'] = pd.cut(hours, 
        bins=[0,6,12,18,24], 
        include_lowest=True, 
        labels=['12am-6am', '6am-12pm', '12pm-6pm', '6pm-12am'])
    ordersByTime_df = pd.DataFrame(orders_df,columns = ['order_date', 'time_period'])
    # print (orders_df)
    ordersByTime_df['order_date'] = pd.to_datetime(ordersByTime_df['order_date'])
    plot_df = (
        ordersByTime_df.groupby([pd.Grouper(key='order_date', freq='W-SAT'), 'time_period'])
            .size()
            .reset_index(name='count')
            .pivot(index='order_date', columns='time_period', values='count')
    )
    # Plot Bar
    plt.clf()
    ax = plot_df.plot(kind='bar', rot=15, xlabel='Weeks (start Date)', ylabel='Number of Orders')
    # Format X-axis ticks
    ax.xaxis.set_major_formatter(
        ticker.FixedFormatter(plot_df.index.strftime('%Y-%m-%d'))
    )
    plt.title("Number of Orders in last one Month (by time period)")
    plt.tight_layout()
    # after saving figure into a bytes object, it can be exposed via flask
    chart = io.BytesIO()
    plt.savefig(chart, format='png')
    chart.seek(0) 
    return chart    

@app.route('/charts', methods=['GET'])
def plotcharts():
    chartName = request.args.get('name')
    userId = request.args.get('userid')
    if chartName == 'movavg':    
        image = movingAverage()
        return send_file(image, mimetype='image/png')
    elif chartName == 'bytime':
        image = plotOrdersByTime()       
        return send_file(image, mimetype='image/png')
    elif chartName == 'popchart':
        image = popularityChart(userId)       
        return send_file(image, mimetype='image/png')

@app.route('/')
@app.route('/predict')
def predictViewer():
    return render_template('predict.html')

#match the order prediction to human interpretation
def expectedOrders(orderIndex):    
        match orderIndex:
            case 0:
                return '<20'
            case 1:
                return '20-40'
            case 2:
                return '40-60'
            case 3:
                return '60-80'
            case 4:
                return '>80'
            case _:
                return 'Something wrong'
            
#match the viewer prediction to human interpretation
def expectedViwers(orderIndex):    
        match orderIndex:
            case 0:
                return '50-100'
            case 1:
                return '100-150'
            case 2:
                return '150-200'
            case 3:
                return '>200'
            case 4:
                return '<50' #<50 is at the last column in the original data (after onhot)
            case _:
                return 'Something wrong'

#ML feature order prediction
#Use the trained models 'ordermodel.h5' and 'viewermodel.5' to predict
@app.route('/result', methods = ['POST'])
def result():
    if request.method == 'POST':
        to_predict_list = request.form.to_dict()
        print(request.form)
        df_incoming = pd.DataFrame([to_predict_list], index=[0])
        
        #read below dataframe that was saved during model creation 
        # to get all column names after one hot encoding
        df_refernce = pd.read_csv('data/x_column_names.csv')   
        #insert a new row with all zero values
        df_refernce.loc[len(df_refernce)] = 0                              
        #one hot encode the incoming dataframe with values for prediction
        df_incoming_onehot = pd.get_dummies(df_incoming, columns=['product_category', 'day', 'time_period'])
        #change the onehot encoded column values to one in the refernce dataframe with all zero values .
        #This make the incoming model encoded with same column names that of during model creation.    
        for column in df_refernce:         
            if column in df_incoming_onehot:                
                df_refernce[column].iloc[0] = 1       
   
        #predit expected viewers by loading the prediction model
        df_to_Predict_encoded = df_refernce 
        loaded_order_model = keras.models.load_model('ordermodel.h5')
        expected_orders = loaded_order_model.predict(df_to_Predict_encoded)
        orderIndex = expected_orders.argmax()
        
         #predit expected orders by loading the prediction model
        loaded_viewer_model = keras.models.load_model('viewermodel.h5')
        expected_viewers = loaded_viewer_model.predict(df_to_Predict_encoded)
        viewerIndex = expected_viewers.argmax()
        
        # return render_template("result.html",prediction="test")
        orederRange = expectedOrders(orderIndex)
        viewerRange = expectedViwers(viewerIndex)
        returndata = [ {k:v} for k,v in zip(["order","viewer"],[orederRange,viewerRange])]                        
        return jsonify(returndata)      

if __name__ == "__main__":
	app.run(debug=True)