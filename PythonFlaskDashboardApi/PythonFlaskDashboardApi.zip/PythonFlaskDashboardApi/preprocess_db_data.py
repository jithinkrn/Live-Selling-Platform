import mysql.connector
import pandas as pd

#local database connection
#user change to your Mysql account username
#password change to your Mysql account password
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="tattatta",
  database="livestream"
)
# # azure server database 
# mydb = mysql.connector.connect(
#   host="gdipsa54team3.mysql.database.azure.com",
#   user="gdipsa54team3",
#   password="6W$3F9&4dsPB&h%q",
#   database="livestream"
# )
db_cursor = mydb.cursor()  
db_cursor.execute('select p.category, o.order_date_time, op.quantity, sl.num_viewers from Product p join order_product op on p.id=op.product_id join orders o on op.order_id=o.id join stream_log sl on sl.stream_id=o.stream_id')  
orders_df = pd.DataFrame(db_cursor.fetchall())
if orders_df.empty:
    print('Database has no record')
    exit()
orders_df.columns =['product_category', 'order_date_time', 'number_of_orders', 'number_of_viewers']
orders_df['order_date_time'] = orders_df['order_date_time'].astype('datetime64[s]')
orders_df['Date'] = pd.to_datetime(orders_df['order_date_time']).dt.date
orders_df['day'] = pd.to_datetime(orders_df['order_date_time']).dt.day_name()
orders_df['time'] = pd.to_datetime(orders_df['order_date_time']).dt.time
orders_df.index.name='index'
day = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI','SAT']
def rename(day):   
        
    if day == 'Monday':
        return "MON"    
    if day == 'Tuesday':
        return "TUE"
    if day == 'Wednesday':
        return "WED"
    if day == 'Thursday':
        return "THU"
    if day == 'Friday':
        return "FRI"
    if day == 'Saturday':
        return "SAT"      
    return "SUN"
orders_df["day"] = orders_df["day"].apply(rename)

df_retraining_data = pd.DataFrame(orders_df, columns=['product_category', 'day', 'time', 'number_of_orders', 'number_of_viewers'])
# df_retraining_data['time'] = pd.to_datetime(df_retraining_data['time']).apply(lambda x: x.replace(microsecond=0))
print (df_retraining_data)
path1 = 'data/retraining_data.csv'
df_retraining_data.to_csv(path1, index=True, header = True)  