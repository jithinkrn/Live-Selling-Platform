I. Application Features:
The application contains the following
    i.  Script to create machine learning model from either generated data or data in database (captured during live stream). file name: "train_ml_model_py"
    ii.  Python flask application that permit API calls to predict orders/viewers based on given inputs
        The application feeds the inputs to the trained models and return the predicted outputs to used and JASON object
    iii.  Python flask application that permit API calls to view below charts
        a. Moving average prediction of orders for the past one month
        b. Bar chart of Orders by time frame for the past one month
        c. Seller popularity chart that show a bar chart that compares a seller vs other sellers.
    iv. Script that shows the distribution (bar chart) of generated data used for initial training of the ML models. 
    v. Reference materials for generating data in the shown pattern in D in the reference_meteral folder. Source is given in the source.txt file  

I. Set up (Windows Machines)
Note that the application already has trained ML models saved. So can directly start the application.
    i.  Install python 3.10 from https://www.python.org/downloads/
    ii. Download the Pip script, from https://pip.pypa.io/en/stable/installation/
    iii. Open a command prompt, cd to the folder containing the dowloaded get-pip.py file and run:
        py get-pip.py
    iv. Open Visual Studio Code and Open the PythonFlaskDashboardApi project (File>Open folder> select PythonFlaskDashboardApi)
    v. Install all dependencies need for the project. Below scrip will install all dependacies automatically. Navigate to the project folder and run:
        pip install -r requirements.txt
    vi. Start MyhSQL local database (go to Services for windows machines> locatate MySQL and start). vi. Start MyhSQL local database if yet started at step 1 (go to Services for windows machines. locatate MySQL and start). Change username and password in the follwing part of the code in 'app.py' file and 'preprocess_db_data.py' file

        #local database connection
		#user change to your Mysql account username
		#password change to your Mysql account password
        
		mydb = mysql.connector.connect(
  		host="localhost",
 	 	user="root", 			
  		password="tattatta",		
 	 	database="livestream"
		)

II. Run the Python Flask APP (Start Server)    
    i. Application is ready to start now. Navigate to the PythonFlaskDashboardApi project folder in the terminal and enter the following  to run flask application
        flask run

III. Re-train the prediction models (Not required to run if do to wish to retrain. The models are already trained and available for prediction in the App)
    i. stop the server by click stop icon in the VS code
    ii. Slect terminal and navigate to the project folder and enter the following to run retarining
        python train.ml_model.py
    iii. One prompted in the console need enter the source of training data, d or g (d for database data and g generated data). Note that as of now database do not have sufficient data since data is yet to be captured when the platform is live and people make orders. So choose 'g' to train from generated data 
    iv. Close the charts when pop up. Onc training complets the models are ready to be used by the application for prediction   

IV. To view the distibution of generated data used for initial training (Not required to run. just FYI)
    i. navigate to the project folder and enter the following in the terminal to run script
    python generated_data_plots.py




