import pandas as pd
from sklearn.model_selection import train_test_split
import tensorflow as tf
import matplotlib.pyplot as plt

# Load dataset
def read_data():
    
    try:
        correctInput = False        
        while (not correctInput) :   
            source = input("Trian the models using database data(d) or generated data(g)? \n(d/g): ")
            if source == "d":
                exec(open('preprocess_db_data.py').read())    
                url = "data/retraining_data.csv"
                correctInput = True
            elif  source == "g":
                url = "data/generated_data.csv" 
                correctInput = True
            else :
                print ("Wrong input! enter 'd' or'g'")

        df = pd.read_csv(url)

        #cotagorize time
        df['time'] =  pd.to_datetime(df['time'], format='%H:%M:%S').dt.time
        df.head()
        bins = ['12am-6am', '6am-12pm', '12pm-6pm', '6pm-12am']
        hours = pd.to_datetime(df['time'], format='%H:%M:%S').dt.hour
        df['time_period'] = pd.cut(hours, 
                            bins=[0,5,11,17,23], 
                            include_lowest=True, 
                            labels=['12am-6am', '6am-12pm', '12pm-6pm', '6pm-12am'])

        #cotagorize Viewers
        def reclassify(viewers):    
                
            if viewers > 200:
                return ">200"    
            if viewers > 150:
                return ">150"
            if viewers > 100:
                return ">100"
            if viewers > 50:
                return ">50"
            return "<50"

        df["number_of_viewers"] = df["number_of_viewers"].apply(reclassify)

        def reclassify(orders):    
                
            if orders > 80:
                return ">80"    
            if orders > 60:
                return ">60"
            if orders > 40:
                return ">40"
            if orders > 20:
                return ">20"
            return "<20"
    

        df["number_of_orders"] = df["number_of_orders"].apply(reclassify)
        #drop time & Index
        df = df.drop(['time', 'index', ], axis=1)
        #If database do not have sufficient data ask trainin using generated data
        if (df['day'].nunique() <7 or df['time_period'].nunique() <4 or df.shape[0]<200) :
            print ("Not enought data in database. \n Please re-run script and train using generated data")
            exit()
        
        return df
    # if files not found
    except FileNotFoundError:
        return None  

#---------------------------------------------------------------------
# Order prediction model creation
#---------------------------------------------------------------------

def createOrderPredictionModel (df):
    X__order_pred = pd.DataFrame(df, columns=['product_category', 'day', 'time_period'])
    y__order_pred = (df["number_of_orders"]) 

    print (X__order_pred.head())
    print (y__order_pred.head())


    # One hot encoding for time prediction
    X__order_pred = pd.get_dummies(X__order_pred, columns=['product_category', 'day', 'time_period'])
    y__order_pred = pd.get_dummies(y__order_pred, columns=['number_of_orders'])

    #save the encoded column names for later use (when predict)
    path1 = 'data/x_column_names.csv'
    df_column_refernce = X__order_pred[0:0] 
    df_column_refernce.to_csv(path1, index=False, header = True)

    #train test split
    x_train_order, x_test_order, y_train_order, y_test_order = train_test_split(
        X__order_pred, y__order_pred, test_size=0.3)
    
    # create neural network 
    model1 = tf.keras.Sequential()
     #100 nuerons in the first hidden layer
    model1.add(tf.keras.layers.Dense(units=100, 
        input_shape=(x_train_order.shape[1],), activation='ReLU'))
    # dropout layer
    model1.add(tf.keras.layers.Dropout(rate=0.1))
    #flatten layer
    model1.add(tf.keras.layers.Flatten())
    #100 nuerons in the second hidden layer
    model1.add(tf.keras.layers.Dense(units=100, activation='ReLU'))
    # dropout layer
    model1.add(tf.keras.layers.Dropout(rate=0.1))
    #flatten layer
    model1.add(tf.keras.layers.Flatten())
    model1.add(tf.keras.layers.Dropout(rate=0.05))
    #output 5 categories
    model1.add(tf.keras.layers.Dense(units=5, activation='softmax'))
   
    # specify that we want to use 'adam' for gradient descent, and 
    # loss function as 'categorical_crossentropy' (softmax), and 
    # acurracy-count as how many test samples are correctly identified
    # as the correct category
    model1.compile(optimizer='Adam', loss='categorical_crossentropy',
        metrics=['accuracy'])
    # train our model
    order_predcition = model1.fit(x_train_order, y_train_order, epochs=50)
    # use our test data to evaluate the accuracy of our classifier
    loss, accuracy = model1.evaluate(x_test_order, y_test_order, verbose=1)
    print(loss, accuracy)
    #Plot loss and accuracy curve
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(12, 5))

    ax[0].plot(order_predcition.history['loss'])
    ax[0].set_xlabel('Epochs')
    ax[0].set_ylabel('Loss')
    ax[0].set_title('Loss Curve')

    ax[1].plot(order_predcition.history['accuracy'])
    ax[1].set_xlabel('Epochs')
    ax[1].set_ylabel('Accuracy')
    ax[1].set_title('Accuracy Curve')

    plt.show()

    #save the model to use for prediction
    model1.save('ordermodel.h5')

#---------------------------------------------------------------------
# Viewer prediction model creation
#---------------------------------------------------------------------
def createViewerPredictionModel (df):
    X__viewer_pred = pd.DataFrame(df, columns=['product_category', 'day', 'time_period'])
    y__viewer_pred = (df["number_of_viewers"]) 

    print (X__viewer_pred.head())
    print (y__viewer_pred.head())

    # One hot encoding for order prediction
    X__viewer_pred = pd.get_dummies(X__viewer_pred, columns=['product_category', 'day', 'time_period'])
    y__viewer_pred = pd.get_dummies(y__viewer_pred, columns=['number_of_viewers'])

    # path1 = 'X__viewer_encoded.csv'
    # path2 = 'y__viewer_encoded.csv'
    # X__viewer_pred.to_csv(path1, index=False, header = True)
    # y__viewer_pred.to_csv(path2, index=False, header = True)
    

    #train test split
    x_train_viewer, x_test_viewer, y_train_viewer, y_test_viewer = train_test_split(
        X__viewer_pred, y__viewer_pred, test_size=0.3)
    # create neural network 
    model2 = tf.keras.Sequential()# Hidden layer
    # x_train.shape[1] provides the number of features (3 in our case)
    # 100 nuerons in the first hidden layer
    model2.add(tf.keras.layers.Dense(units=100, 
        input_shape=(x_train_viewer.shape[1],), activation='ReLU'))
    # dropout hidden layer
    model2.add(tf.keras.layers.Dropout(rate=0.1))
    #flatten layer
    model2.add(tf.keras.layers.Flatten())
    #100 nuerons in the second hidden layer
    model2.add(tf.keras.layers.Dense(units=100, activation='ReLU'))
    # dropout layer
    model2.add(tf.keras.layers.Dropout(rate=0.1))
    #flatten layer
    model2.add(tf.keras.layers.Flatten())
    model2.add(tf.keras.layers.Dropout(rate=0.05))
    #output 5 categories
    model2.add(tf.keras.layers.Dense(units=5, activation='softmax'))
    # specify that we want to use 'adam' for gradient descent, and 
    # loss function as 'categorical_crossentropy' (softmax), and 
    # acurracy-count as how many test samples are correctly identified
    # as the correct category
    model2.compile(optimizer='Adam', loss='categorical_crossentropy',
        metrics=['accuracy'])
    # train our model
    viewer_predcition = model2.fit(x_train_viewer, y_train_viewer, epochs=30)
    # use our test data to evaluate the accuracy of our classifier
    loss, accuracy = model2.evaluate(x_test_viewer, y_test_viewer, verbose=1)
    print(loss, accuracy)
    #Plot loss and accuracy curve
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(12, 5))

    ax[0].plot(viewer_predcition.history['loss'])
    ax[0].set_xlabel('Epochs')
    ax[0].set_ylabel('Loss')
    ax[0].set_title('Loss Curve')

    ax[1].plot(viewer_predcition.history['accuracy'])
    ax[1].set_xlabel('Epochs')
    ax[1].set_ylabel('Accuracy')
    ax[1].set_title('Accuracy Curve')

    plt.show()
    #save the model to use for prediction
    model2.save('viewermodel.h5')

def main():
    training_data = read_data()
    createOrderPredictionModel(training_data)
    createViewerPredictionModel(training_data)

if __name__ == "__main__":
	main()