import pandas as pd
import matplotlib.pyplot as plt


def show_charts() :
    # Load dataset
    url = "data/generated_data.csv"
    df = pd.read_csv(url)
    #cotagorize time
    df['time'] =  pd.to_datetime(df['time'], format='%H:%M:%S').dt.time
    bins = ['12am-6am', '6am-12pm', '12pm-6pm', '6pm-12am']
    hours = pd.to_datetime(df['time'], format='%H:%M:%S').dt.hour
    df['time_period'] = pd.cut(hours, 
                        bins=[0,5,11,17,23], 
                        include_lowest=True, 
                        labels=['12am-6am', '6am-12pm', '12pm-6pm', '6pm-12am'])
    #drop time & Index
    df = df.drop(['time', 'index', ], axis=1)
    print (df)
    df_time_orders = pd.DataFrame(df, columns = ['time_period', 'number_of_orders'])
    df_time_orders.groupby(by = "time_period").sum().sort_values('number_of_orders', ascending=False).plot(kind = "bar", rot=15)
    df2 = df_time_orders.groupby(by = "time_period").sum().sort_values('number_of_orders', ascending=False)
    print (df2)
    # df_time = df.iloc[key.argsort()]
    plt.title("Number of Orders")
    plt.ylabel("Total Orders")
    plt.savefig('data/order_vs_time_generated')
    plt.show()

    #Time period vs number of viewers chart
    # df_time_viewers = df.iloc[key.argsort()]
    df_time_viewers = pd.DataFrame(df, columns = ['time_period', 'number_of_viewers'])
    df_time_viewers.groupby(by = "time_period").sum().sort_values('number_of_viewers', ascending=False).plot(kind = "bar", rot=15)
    plt.title("Number of Viewers")
    plt.ylabel("Total Viewers")
    plt.savefig('data/viewer_vs_time_generated')
    plt.show()

    #Day vs number of orders chartd
    df_day_orders = pd.DataFrame(df, columns = ['day', 'number_of_orders'])
    df_day_orders.groupby(by = "day").mean().sort_values('number_of_orders', ascending=False).plot(kind = "bar", rot=15)
    plt.title("Number of Orders")
    plt.ylabel("Average Number of Orders")
    plt.savefig('data/order_vs_day_generated')
    plt.show()

    #Day vs number of viewers chart
    df_day_viewers = pd.DataFrame(df, columns = ['day', 'number_of_viewers'])
    df_day_viewers.groupby(by = "day").mean().sort_values('number_of_viewers', ascending=False).plot(kind = "bar", rot=15)
    plt.title("Number of Viewers")
    plt.ylabel("Average Number of Viewers")
    plt.savefig('data/viewer_vs_day_generated')
    plt.show()

def main():
    show_charts()
            
if __name__ == "__main__":
	main()